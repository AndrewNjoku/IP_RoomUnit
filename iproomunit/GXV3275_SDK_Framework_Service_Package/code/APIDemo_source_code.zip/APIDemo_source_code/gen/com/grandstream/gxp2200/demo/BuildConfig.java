/** Automatically generated file. DO NOT MODIFY */
package com.grandstream.gxp2200.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}